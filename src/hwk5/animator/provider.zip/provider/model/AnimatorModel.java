package hwk5.animator.provider.model;

import java.util.List;
import java.util.NoSuchElementException;

/**
 * An interface for the model of an animation of renderable Shapes.
 *
 * @param <Waypoint> a generic parameter for the implementation of the state of the Shape at any
 *                   point.
 */
public interface AnimatorModel<Waypoint> extends ViewModel {

  /**
   * Returns a list of all shapes in this model.
   *
   * @return the list
   */
  List<Shape<Waypoint>> getShapes();

  /**
   * Returns the list of waypoints for the requested shape.
   *
   * @param shapeName Name of requested Shape.
   * @return List of waypoints.
   * @throws IllegalArgumentException if the requested shape does not exist.
   */
  List<Waypoint> getShapeWaypoints(String shapeName) throws IllegalArgumentException;

  /**
   * Adds a given shape to the foreground of the animation.
   *
   * @param s the shape to be added
   * @throws IllegalArgumentException if a shape with the name of the given shape already exists in
   *                                  the list of shapes.
   */
  void addShape(Shape<Waypoint> s) throws IllegalArgumentException;

  /**
   * Removes the Shape with the given name from the list of shapes.
   *
   * @param name the name of the shape to remove
   * @return the shape that was removed
   * @throws NoSuchElementException if no shape with the given name exists
   */
  Shape<Waypoint> removeShape(String name) throws NoSuchElementException;

  /**
   * Adds a given waypoint to the shape of the given name, if it exists.
   *
   * @param name  name of shape to be modified
   * @param state waypoint state to be added to shape
   * @throws NoSuchElementException if no shape with the given name exists.
   */
  void addWaypoint(String name, Waypoint state) throws NoSuchElementException;

  /**
   * Removes the waypoint with the given tick from the Shape with the given name.
   *
   * @param name the name of the shape to remove the waypoint from
   * @param tick the tick on which the waypoint occurs
   * @return the waypoint
   * @throws NoSuchElementException if no shape with the given name exists or if no waypoint in the
   *                                Shape occurs at the given tick.
   */
  Waypoint removeWaypoint(String name, int tick) throws NoSuchElementException;
  
  /**
   * String representation of this model, parsable by EasyAnimatorModel.Builder.
   *
   * @return the String representation.
   */
  String toPlaintext();
}
