package hwk5.animator.provider.model;

import java.awt.Graphics;
import java.awt.Point;

/**
 * A Read-only shape with all the observations necessary for the viewing of an animation.
 */
public interface ViewShape {

  /**
   * Uses Java Swing library to render this shape onto a surrounding canvas.
   *
   * @param tick the tick to render the Shape at.
   * @param g    graphics object to be drawn on.
   * @param p    the corner point of the graphics g.
   */
  void render(int tick, Graphics g, Point p);

  /**
   * Returns a String descriptor of this shape, using the unit of seconds to communicate the state
   * of the shape throughout time.
   *
   * @param tps ticks per second
   * @return string description
   */
  String toPlaintext(int tps);

  /**
   * Returns a String representation of this shape in the SVG format.
   *
   * @param tps the ticks per second to display the animation at
   * @param p   the point representing the top left of the animation
   */
  String toSVG(int tps, Point p);
}
