package hwk5.animator.provider.model;

import java.util.List;

/**
 * The interface representing the functionality of a Shape in an EasyAnimatorModel.
 *
 * @param <T> The class which represents the state of an Shape implementation
 */
public interface Shape<T> extends ViewShape {

  /**
   * Returns the list of waypoint states in this Shape.
   *
   * @return the list of waypoints states;
   */
  List<T> getWaypoints();

  /**
   * Currently for making observations on the Shapes, probably will be made private later. Returns
   * null if the given tick is before or after this Shape exists in the animation.
   *
   * @param tick the tick to get the state of this Shape for
   * @return the T object describing the state of this shape.
   * @throws IllegalArgumentException if the given tick is negative
   */
  T getState(int tick) throws IllegalArgumentException;

  /**
   * Adds a waypoint to this shape.
   *
   * @param state the state of the shape at the waypoint
   */
  void addWaypoint(T state);

  /**
   * Removes a waypoint state at a given tick, if it exists. Returns null if there is not a waypoint
   * at this tick.
   *
   * @param tick the tick of a waypoint to remove
   * @return the waypoint if a waypoint at that tick was found, or null if no waypoint was found
   */
  T removeWaypoint(int tick);

  /**
   * Returns a String identifier of this Shape.
   *
   * @return the name of this Shape
   */
  String getName();

  /**
   * Creates a deep copy of this shape.
   *
   * @return the copy
   */
  Shape<T> copy();

  /**
   * String representation of this shape, parsable by EasyAnimatorModel.Builder.
   *
   * @return the String representation.
   */
  String toPlaintext();
}
