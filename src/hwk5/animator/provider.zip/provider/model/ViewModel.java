package hwk5.animator.provider.model;

import java.util.List;

/**
 * An interface for observations necessary on a model by an AnimatorView.
 */
public interface ViewModel {

  /**
   * Returns a list of all the shapes in this model as renderable ViewShapes.
   *
   * @return the list as ViewShapes
   */
  List<ViewShape> getViewShapes();

  /**
   * Returns the last tick any shape exists in this animation.
   *
   * @return the last tick
   */
  int getLastTick();

  /**
   * Returns the x-coordinate of the top-left corner of the canvas.
   *
   * @return the x-coordinate of the top-left corner of the canvas.
   */
  int getX();

  /**
   * Returns the y-coordinate of the top-left corner of the canvas.
   *
   * @return the y-coordinate of the top-left corner of the canvas.
   */
  int getY();

  /**
   * Returns the width of the top-left corner of the canvas.
   *
   * @return the width of the top-left corner of the canvas.
   */
  int getWidth();

  /**
   * Returns the height of the top-left corner of the canvas.
   *
   * @return the height of the top-left corner of the canvas.
   */
  int getHeight();
}
