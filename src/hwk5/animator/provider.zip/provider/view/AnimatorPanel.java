package hwk5.animator.provider.view;

import static java.util.Objects.requireNonNull;

import hwk5.animator.provider.model.ViewModel;
import hwk5.animator.provider.model.ViewShape;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.util.Objects;
import javax.swing.JPanel;

/**
 * The panel holding all shapes drawn in the animation.
 */
public class AnimatorPanel extends JPanel {

  private final ViewModel model;

  private int tick;

  /**
   * Constructor to initialize the model and set the attributes of the panel.
   */
  public AnimatorPanel(ViewModel model) {
    super();
    this.model = requireNonNull(model);
    this.setLocation(model.getX(), model.getY());
    this.setPreferredSize(new Dimension(model.getWidth(), model.getHeight()));
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AnimatorPanel that = (AnimatorPanel) o;
    return tick == that.tick && Objects.equals(model, that.model);
  }

  @Override
  public int hashCode() {
    return Objects.hash(model, tick);
  }

  @Override
  public void paint(Graphics g) {
    super.paint(g);
    for (ViewShape s : this.model.getViewShapes()) {
      s.render(this.tick, g, new Point(this.model.getX(), this.model.getY()));
    }
  }

  /**
   * Sets the current tick of the panel, ensuring that it is non-negative.
   *
   * @param tick the tick to set
   */
  public void setTick(int tick) {
    if (tick < 0) {
      throw new IllegalArgumentException();
    }
    this.tick = tick;
  }
  
  /**
   * Is this panel empty - do no shapes exist in the animation at the current tick.
   * @return if the model has no shapes which exist at this tick
   */
  public boolean isEmpty() {
    return this.tick > model.getLastTick();
  }
}
