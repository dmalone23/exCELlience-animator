package hwk5.animator.provider.view;

import static java.util.Objects.hash;
import static java.util.Objects.requireNonNull;

import hwk5.animator.provider.model.ViewModel;
import java.util.Objects;

/**
 * Abstract class representing an AnimatorView that somehow represents the animation in text.
 */
public abstract class AAnimatorTextView implements AnimatorView {

  protected final Appendable out;
  protected final ViewModel model;

  /**
   * Constructor taking in an Appendable to append to and a read-only model to view the shapes of.
   *
   * @param out   where to write output to
   * @param model the model being viewed
   */
  public AAnimatorTextView(Appendable out, ViewModel model) {
    this.out = requireNonNull(out);
    this.model = requireNonNull(model);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AAnimatorTextView that = (AAnimatorTextView) o;
    return Objects.equals(out, that.out) && Objects.equals(model, that.model);
  }

  @Override
  public int hashCode() {
    return hash(out, model);
  }
}
