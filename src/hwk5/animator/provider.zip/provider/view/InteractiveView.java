package hwk5.animator.provider.view;

/**
 * An interface for a view with interactive controls over the animation.
 */
public interface InteractiveView extends AnimatorView {
  /**
   * Start the animation from the beginning, or restart it if it is currently playing.
   */
  void start();
  
  /**
   * Either pause or unpause the animation, depending on the current state.
   */
  void togglePaused();
  
  /**
   * Either enable or disable looping, depending on the current state.
   */
  void toggleLooping();
  
  /**
   * Increase the tick rate by an amount determined by the implementation.
   */
  void increaseSpeed();
  
  /**
   * Decrease the tick rate by an amount determined by the implementation.
   */
  void decreaseSpeed();
}
