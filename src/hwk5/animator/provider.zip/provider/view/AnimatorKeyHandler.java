package hwk5.animator.provider.view;

import static java.util.Objects.requireNonNull;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.HashMap;
import java.util.Map;

/**
 * Key handler for an interactive Animator View.
 */
public class AnimatorKeyHandler implements KeyListener {

  // map of KeyCodes to the methods invoked on the above view.
  private final Map<Integer, Runnable> keyLambdaMap;

  /**
   * Constructor to initialize the map of keys pressed to actions on the given view.
   *
   * @param view the view this key handler acts on and is a part of.
   */
  public AnimatorKeyHandler(InteractiveView view) {
    requireNonNull(view);
    this.keyLambdaMap = new HashMap<>();
    this.keyLambdaMap.put(KeyEvent.VK_R, view::start);
    this.keyLambdaMap.put(KeyEvent.VK_L, view::toggleLooping);
    this.keyLambdaMap.put(KeyEvent.VK_SPACE, view::togglePaused);
    this.keyLambdaMap.put(KeyEvent.VK_UP, view::increaseSpeed);
    this.keyLambdaMap.put(KeyEvent.VK_DOWN, view::decreaseSpeed);
  }

  /**
   * Invoked when a key has been typed. See the class description for {@link KeyEvent} for a
   * definition of a key typed event.
   *
   * @param e the event to be processed
   */
  @Override
  public void keyTyped(KeyEvent e) {
    // empty since we are only using keyPressed for this key handler
  }

  /**
   * Invoked when a key has been pressed. See the class description for {@link KeyEvent} for a
   * definition of a key pressed event.
   *
   * @param e the event to be processed
   */
  @Override
  public void keyPressed(KeyEvent e) {
    Runnable run = this.keyLambdaMap.getOrDefault(e.getKeyCode(), () -> {
    });
    run.run();
  }

  /**
   * Invoked when a key has been released. See the class description for {@link KeyEvent} for a
   * definition of a key released event.
   *
   * @param e the event to be processed
   */
  @Override
  public void keyReleased(KeyEvent e) {
    // empty since we are only using keyPressed for this key handler
  }
}
