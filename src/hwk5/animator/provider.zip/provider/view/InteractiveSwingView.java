package hwk5.animator.provider.view;

import static java.util.Objects.requireNonNull;

import hwk5.animator.provider.model.ViewModel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.Timer;

/**
 * An interactive animation view using the Java Swing library.
 */
public class InteractiveSwingView extends JFrame implements InteractiveView {

  private final AnimatorPanel panel;
  private final ViewModel model;
  // changeable Timer reference for changing speed of animation
  private Timer timer;
  private int tick;
  private int tps;

  private boolean paused;
  private boolean loop;
  private final int speedDelta = 5;

  // label references for use in methods.
  private final JLabel tpsLabel;
  private final JLabel loopingLabel;

  /**
   * Constructor to initialize the View with the model it will be presenting.
   *
   * @param model The ViewModel to be displayed.
   */
  public InteractiveSwingView(ViewModel model) {
    super("Interactive Animator");
    this.model = requireNonNull(model);
    this.panel = new AnimatorPanel(requireNonNull(model));

    // standard window size
    this.setSize(new Dimension(1366, 768));
    this.setDefaultCloseOperation(InteractiveSwingView.EXIT_ON_CLOSE);

    // add a JScrollPane to the JFrame with scrollbars always showing
    JScrollPane scrollPane =
        new JScrollPane(
            this.panel,
            ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
            ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

    this.add(scrollPane, BorderLayout.CENTER);

    // pane for adding buttons and label fields to the toolbar.s
    JPanel toolbar = new JPanel();

    JButton play = new JButton("Play/Pause (Space)");
    play.addActionListener(e -> togglePaused());
    play.setFocusable(false);

    JButton speedUp = new JButton("Increase TPS (Up Arrow)");
    speedUp.addActionListener(e -> increaseSpeed());
    speedUp.setFocusable(false);

    JButton speedDown = new JButton("Decrease TPS (Down Arrow)");
    speedDown.addActionListener(e -> decreaseSpeed());
    speedDown.setFocusable(false);

    JButton toggleLooping = new JButton("Toggle Looping (L)");
    toggleLooping.addActionListener(e -> toggleLooping());
    toggleLooping.setFocusable(false);

    JButton start = new JButton("Start/Restart (R)");
    start.addActionListener(e -> start());
    start.setFocusable(false);

    this.tpsLabel = new JLabel("TPS: " + this.tps);

    this.loopingLabel = new JLabel("Looping: " + this.loop);

    toolbar.add(start);
    toolbar.add(play);
    toolbar.add(toggleLooping);
    toolbar.add(speedDown);
    toolbar.add(speedUp);
    toolbar.add(tpsLabel);
    toolbar.add(loopingLabel);
    this.add(toolbar, BorderLayout.PAGE_END);

    // default values for boolean fields
    this.loop = false;
    this.paused = false;

    // key handler for the same actions as the buttons
    this.addKeyListener(new AnimatorKeyHandler(this));
  }

  /**
   * Start the animation from the beginning, or restart it if it is currently playing.
   */
  @Override
  public void start() {
    this.tick = 0;
    this.paused = false;
    this.timer = new Timer(1000 / this.tps, new Repainter());
    timer.start();
  }

  /**
   * Either pause or unpause the animation, depending on the current state.
   */
  @Override
  public void togglePaused() {
    this.paused = !this.paused;
  }

  /**
   * Either enable or disable looping, depending on the current state.
   */
  @Override
  public void toggleLooping() {
    this.loop = !this.loop;
    this.loopingLabel.setText("Looping: " + this.loop);
  }

  /**
   * Increase the tick rate by 1 tps.
   */
  @Override
  public void increaseSpeed() {
    this.changeTPS(this.tps + this.speedDelta);
  }

  /**
   * Decrease the tick rate by 1 tps.
   */
  @Override
  public void decreaseSpeed() {
    this.changeTPS(Math.max(1, this.tps - this.speedDelta));
  }

  /**
   * Abstracted code to modify the speed of the animation.
   *
   * @param tps new ticks per second
   */
  private void changeTPS(int tps) {
    this.tps = tps;
    this.tpsLabel.setText("TPS: " + this.tps);
    if (this.timer != null) {
      this.timer.setDelay(1000 / this.tps);
    }
  }

  /**
   * Displays the entire animation according to the details of this view implementation.
   *
   * @param tps ticks per second for this animation.
   */
  @Override
  public void render(int tps) {
    this.setVisible(true);
    this.tps = tps;
    this.tpsLabel.setText("TPS: " + this.tps);
  }

  /**
   * Action Listener for use in Timers to redraw the animation on the panel.
   */
  private class Repainter implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent e) {
      // clear canvas, render model at current tick, increment tick.
      if (!paused) {
        repaint();
        panel.setTick(tick);
        tick++;
        if (loop && tick > model.getLastTick()) {
          tick = 0;
        }
      }
    }
  }
}
