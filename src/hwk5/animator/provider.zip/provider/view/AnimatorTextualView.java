package hwk5.animator.provider.view;

import hwk5.animator.provider.model.ViewModel;
import hwk5.animator.provider.model.ViewShape;
import java.io.IOException;

/**
 * AnimatorView displaying the animation as a list of shapes and their motions.
 */
public class AnimatorTextualView extends AAnimatorTextView {

  /**
   * Constructor calling super with an Appendable and a ViewModel.
   *
   * @param out   where to write output to
   * @param model the model being viewed
   */
  public AnimatorTextualView(Appendable out, ViewModel model) {
    super(out, model);
  }

  @Override
  public void render(int tps) throws IOException {
    StringBuilder s = new StringBuilder();
    // canvas description
    s.append("canvas ")
        .append(this.model.getX())
        .append(" ")
        .append(this.model.getY())
        .append(" ")
        .append(this.model.getWidth())
        .append(" ")
        .append(this.model.getHeight())
        .append("\n");
    // appends the plaintext representation of each shape in this model
    for (ViewShape shape : this.model.getViewShapes()) {
      s.append(shape.toPlaintext(tps));
    }
    this.out.append(s.toString());
  }
}
