package hwk5.animator.provider.view;

import java.io.IOException;

/**
 * An interface for the functionality to view the animation described in an AnimationModel.
 */
public interface AnimatorView {

  /**
   * Displays the entire animation according to the details of this view implementation.
   *
   * @param tps ticks per second for this animation.
   */
  void render(int tps) throws IOException;
}
