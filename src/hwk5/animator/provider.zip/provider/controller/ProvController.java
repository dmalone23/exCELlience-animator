package hwk5.animator.provider.controller;

import hwk5.animator.provider.model.ViewModel;
import hwk5.animator.provider.view.AnimatorTextualView;
import hwk5.animator.provider.view.AnimatorView;
import hwk5.animator.provider.view.InteractiveSwingView;
import hwk5.model.Animation;
import hwk5.model.ShapesModel;
import hwk5.model.ShapesModel.ShapesModelFactory;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import javax.swing.Timer;

public class ProvController {
  private Scanner scan;
  private AnimatorView viewer;
  private Animation mod;
  private boolean quit;
  private Timer tim;
  private String in;
  private String out;
  private Readable rd;
  private int tPS;
  private int[] curTick;
  private boolean looping;
  private String viewType;

  /**
   * The constructor for a controller object.
   *
   * @param input  the input being fed to the controller.
   * @param output the output destination of the controller.
   * @param tps    the ticks per second.
   */
  public ProvController(String view, String input, String output, int tps)
      throws IllegalArgumentException {
    if (view == null || input == null || output == null || tps < 0) {
      throw new IllegalArgumentException();
    }
    mod = new ShapesModel();
    ViewModel m = mod;
    if (view.equalsIgnoreCase("Provider Interactive")) {
      viewer = new InteractiveSwingView(m);
      viewType = "interactive";
    } else {
      viewer = new AnimatorTextualView(new StringBuilder(), m);
      viewType = "textual";
    }

    tPS = tps;
    in = input;
    out = output;
    curTick = new int[]{0};
    looping = false;
  }


  /**
   * Starts the animation or renders the output of the given controller.
   */
  public void startAnimation() throws FileNotFoundException {
    doIn();
    for (int i = 0; i < mod.getFinalTick(); i++) {
      mod.doTick(i);
    }
    StringBuilder s = new StringBuilder();

    if (viewType.equalsIgnoreCase("interactive")) {
      viewer = new InteractiveSwingView(mod);
    } else {
      viewer = new AnimatorTextualView(s, mod);
    }

    try {
      viewer.render(tPS);
      System.out.println(mod.getLastTick());
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * Read the input file and act accordingly based on the type of controller.
   * @throws IllegalStateException if given an unsupported operation when rendering
   * @throws FileNotFoundException if given a file that does not exist/incorrect filepath
   */
  private void doIn() throws FileNotFoundException {
    File in = new File(this.in);
    Scanner myReader = new Scanner(in);
    ShapesModelFactory s = new ShapesModelFactory();
    while (myReader.hasNext()) {
      String cmd = myReader.next();
      if (cmd.equalsIgnoreCase("canvas")) {
        s.setBounds(myReader.nextInt(), myReader.nextInt(), myReader.nextInt(), myReader.nextInt());
      } else if (cmd.equalsIgnoreCase("motion")) {
        s.addMotion(myReader.next(), myReader.nextInt(), myReader.nextInt(), myReader.nextInt(),
            myReader.nextInt(), myReader.nextInt(), myReader.nextInt(), myReader.nextInt(),
            myReader.nextInt(),
            myReader.nextInt(), myReader.nextInt(), myReader.nextInt(), myReader.nextInt(),
            myReader.nextInt(), myReader.nextInt(), myReader.nextInt(), myReader.nextInt());
      } else if (cmd.equalsIgnoreCase("shape")) {
        s.declareShape(myReader.next(), myReader.next());
      }
    }
    mod = s.build();

  }
}
